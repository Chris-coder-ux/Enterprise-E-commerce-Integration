/**
 * Dashboard Principal - Punto de Entrada
 * 
 * Este archivo orquesta todos los módulos del dashboard.
 * Mantiene la compatibilidad con el código existente mientras
 * organiza la inicialización de forma modular.
 * 
 * @file dashboard.js
 * @since 1.0.0
 * @author Christian
 */

/* global jQuery, miIntegracionApiDashboard, ErrorHandler, AjaxManager, SystemEventManager, SELECTORS, DASHBOARD_CONFIG, ConsoleManager */

// ========================================
// VERIFICACIÓN DE DEPENDENCIAS
// ========================================

(function() {
  'use strict';

  // Verificar jQuery
  if (typeof jQuery === 'undefined') {
    console.error('jQuery no está disponible. El dashboard no funcionará.');
    return;
  }

  // Verificar configuración
  if (typeof miIntegracionApiDashboard === 'undefined') {
    console.error('miIntegracionApiDashboard no está definido. El dashboard no funcionará.');
    return;
  }

  // Verificar ErrorHandler (debe estar cargado como dependencia)
  if (typeof ErrorHandler === 'undefined') {
    console.error('ErrorHandler no está disponible. Asegúrate de que ErrorHandler.js se carga antes de dashboard.js.');
    return;
  }

  // Verificar AjaxManager (debe estar cargado como dependencia)
  if (typeof AjaxManager === 'undefined') {
    console.error('AjaxManager no está disponible. Asegúrate de que AjaxManager.js se carga antes de dashboard.js.');
    return;
  }

  // Verificar SystemEventManager (debe estar cargado como dependencia)
  if (typeof SystemEventManager === 'undefined') {
    console.error('SystemEventManager no está disponible. Asegúrate de que EventManager.js se carga antes de dashboard.js.');
    return;
  }

  // Verificar SELECTORS (debe estar cargado como dependencia)
  if (typeof SELECTORS === 'undefined') {
    console.error('SELECTORS no está disponible. Asegúrate de que constants.js se carga antes de dashboard.js.');
    return;
  }

  // Verificar DASHBOARD_CONFIG (debe estar cargado como dependencia)
  if (typeof DASHBOARD_CONFIG === 'undefined') {
    console.error('DASHBOARD_CONFIG no está disponible. Asegúrate de que dashboard-config.js se carga antes de dashboard.js.');
    return;
  }

  // ========================================
  // INICIALIZACIÓN PRINCIPAL
  // ========================================

  jQuery(document).ready(function() {
    // eslint-disable-next-line no-console
    console.log('🚀 Inicializando Dashboard...');

    // 1. Inicializar sistemas base (core)
    initializeCoreSystems();

    // 2. Inicializar componentes UI
    initializeUIComponents();

    // Nota: Implementar inicialización de otros módulos según se vayan refactorizando
    // 3. initializeManagers();
    // 4. initializeSyncSystem();
    // 5. initializeDashboards();
    // 6. initializeMainController();
    // 7. setupGlobalEvents();

    // eslint-disable-next-line no-console
    console.log('✅ Dashboard inicializado correctamente');
  });

  // ========================================
  // FUNCIONES DE INICIALIZACIÓN
  // ========================================

  /**
   * Inicializar sistemas core
   * 
   * Verifica y expone globalmente los sistemas base del dashboard.
   */
  function initializeCoreSystems() {
    // eslint-disable-next-line no-console
    console.log('🔧 Inicializando sistemas core...');

    // SELECTORS ya está disponible globalmente (cargado como dependencia)
    // Verificación ya realizada arriba, solo asegurar exposición en window
    // Nota: Usamos window en lugar de globalThis para compatibilidad con WordPress
    // eslint-disable-next-line no-restricted-globals
    if (window !== undefined && window.SELECTORS === undefined && typeof SELECTORS !== 'undefined') {
      // eslint-disable-next-line no-restricted-globals
      window.SELECTORS = SELECTORS;
    }
    // eslint-disable-next-line no-console
    console.log('  ✅ SELECTORS inicializado');

    // DASHBOARD_CONFIG ya está disponible globalmente (cargado como dependencia)
    // Verificación ya realizada arriba, solo asegurar exposición en window
    // Nota: Usamos window en lugar de globalThis para compatibilidad con WordPress
    // eslint-disable-next-line no-restricted-globals
    if (window !== undefined && window.DASHBOARD_CONFIG === undefined && typeof DASHBOARD_CONFIG !== 'undefined') {
      // eslint-disable-next-line no-restricted-globals
      window.DASHBOARD_CONFIG = DASHBOARD_CONFIG;
    }
    // eslint-disable-next-line no-console
    console.log('  ✅ DASHBOARD_CONFIG inicializado');

    // ErrorHandler ya está disponible globalmente (cargado como dependencia)
    // Verificación ya realizada arriba, solo asegurar exposición en window
    // Nota: Usamos window en lugar de globalThis para compatibilidad con WordPress
    // eslint-disable-next-line no-restricted-globals
    if (window !== undefined && window.ErrorHandler === undefined) {
      // eslint-disable-next-line no-restricted-globals
      window.ErrorHandler = ErrorHandler;
    }
    // eslint-disable-next-line no-console
    console.log('  ✅ ErrorHandler inicializado');

    // AjaxManager ya está disponible globalmente (cargado como dependencia)
    // Verificación ya realizada arriba, solo asegurar exposición en window
    // Nota: Usamos window en lugar de globalThis para compatibilidad con WordPress
    // eslint-disable-next-line no-restricted-globals
    if (window !== undefined && window.AjaxManager === undefined) {
      // eslint-disable-next-line no-restricted-globals
      window.AjaxManager = AjaxManager;
    }
    // eslint-disable-next-line no-console
    console.log('  ✅ AjaxManager inicializado');

    // SystemEventManager ya está disponible globalmente (cargado como dependencia)
    // Verificación ya realizada arriba, inicializar y emitir eventos
    // eslint-disable-next-line no-restricted-globals
    if (window !== undefined && window.SystemEventManager === undefined) {
      // eslint-disable-next-line no-restricted-globals
      window.SystemEventManager = SystemEventManager;
    }
    // Inicializar el sistema de eventos
    if (typeof SystemEventManager !== 'undefined') {
      SystemEventManager.init();
      SystemEventManager.emitErrorHandlerReady();
      // eslint-disable-next-line no-console
      console.log('  ✅ SystemEventManager inicializado');
    }
  }

  /**
   * Inicializar componentes UI
   * 
   * Inicializa los componentes de interfaz de usuario del dashboard.
   */
  function initializeUIComponents() {
    // eslint-disable-next-line no-console
    console.log('🎨 Inicializando componentes UI...');

    // ConsoleManager - Consola de sincronización en tiempo real
    if (typeof ConsoleManager !== 'undefined' && ConsoleManager && typeof ConsoleManager.initialize === 'function') {
      ConsoleManager.initialize();
      // eslint-disable-next-line no-console
      console.log('  ✅ ConsoleManager inicializado');
    } else {
      // eslint-disable-next-line no-console
      console.warn('  ⚠️  ConsoleManager no está disponible');
    }
  }

})();
