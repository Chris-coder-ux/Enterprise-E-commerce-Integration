/**
 * FormatUtils - Utilidades de Formato
 * 
 * Funciones para formatear datos (bytes, fechas, números, etc.).
 * 
 * @module utils/FormatUtils
 * @since 1.0.0
 * @author Christian
 */

// TODO: Extraer funciones de formato desde dashboard.js (formatBytes, etc.)

