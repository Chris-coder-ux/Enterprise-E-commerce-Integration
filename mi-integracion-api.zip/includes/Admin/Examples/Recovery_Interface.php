<?php declare(strict_types=1);
/**
 * Interfaz de recuperación para ejemplos (archivo legacy)
 *
 * @package MiIntegracionApi\Admin\Examples
 */