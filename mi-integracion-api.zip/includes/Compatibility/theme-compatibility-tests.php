<?php declare(strict_types=1);
/**
 * Tests de compatibilidad con temas (archivo legacy)
 *
 * @package MiIntegracionApi\Compatibility
 */