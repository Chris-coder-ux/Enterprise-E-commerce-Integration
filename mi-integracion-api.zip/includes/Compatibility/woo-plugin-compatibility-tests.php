<?php declare(strict_types=1);
/**
 * Tests de compatibilidad con plugins WooCommerce (archivo legacy)
 *
 * @package MiIntegracionApi\Compatibility
 */