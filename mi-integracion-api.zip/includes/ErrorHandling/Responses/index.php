<?php
declare(strict_types=1);
// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}
