<?php

declare(strict_types=1);

// Silencio es dorado
// Este archivo existe para evitar listados de directorio
