<?php declare(strict_types=1);
/**
 * Trait para optimización de memoria
 *
 * @package MiIntegracionApi\Improvements
 */
namespace MiIntegracionApi\Improvements;