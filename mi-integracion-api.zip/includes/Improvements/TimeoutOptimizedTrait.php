<?php declare(strict_types=1);
/**
 * Trait para optimización de timeouts
 *
 * @package MiIntegracionApi\Improvements
 */
namespace MiIntegracionApi\Improvements;