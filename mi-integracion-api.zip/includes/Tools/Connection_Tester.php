<?php

declare(strict_types=1);

/**
 * Clase para integrar las pruebas de conexión con el plugin principal
 * 
 * Esta clase maneja la ejecución de pruebas desde el panel de administración de WordPress
 * y expone los resultados para ser mostrados en el panel.
 * 
 * @package     MiIntegracionApi
 * @subpackage  Tools
 */

namespace MiIntegracionApi\Tools;

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente
}

class Connection_Tester {
    
    /**
     * Directorio base del plugin
     * 
     * @var string
     */
    private $plugin_dir;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->plugin_dir = dirname(dirname(dirname(__FILE__)));
        
        // Inicializar hooks
        add_action('admin_init', array($this, 'handle_test_actions'));
    }
    
    /**
     * Manejar acciones de prueba desde el panel de administración
     */
    public function handle_test_actions() {
        if (!isset($_GET['page']) || $_GET['page'] !== 'mi-integracion-api-test') {
            return;
        }
        
        if (isset($_POST['run_test']) && check_admin_referer('run_verial_test')) {
            $test_type = sanitize_text_field($_POST['test_type']);
            $this->run_test($test_type);
        }
    }
    
    /**
     * Ejecutar prueba según el tipo seleccionado
     * 
     * @param string $test_type El tipo de prueba a ejecutar
     * @return \MiIntegracionApi\ErrorHandling\Responses\SyncResponseInterface
     */
    public function run_test($test_type): \MiIntegracionApi\ErrorHandling\Responses\SyncResponseInterface {
        // Verificar permisos
        if (!current_user_can('manage_woocommerce')) {
            return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::error(
                __('No tienes permisos para ejecutar pruebas.', 'mi-integracion-api'),
                403,
                [
                    'endpoint' => 'Connection_Tester::run_test',
                    'error_code' => 'permission_denied',
                    'test_type' => $test_type,
                    'timestamp' => time()
                ]
            );
        }
        
        switch ($test_type) {
            case 'connection':
                return $this->run_connection_test();
                
            case 'product_sync':
                return $this->run_product_sync_test();
                
            case 'all':
                $conn_result = $this->run_connection_test();
                $prod_result = $this->run_product_sync_test();
                
                if ($conn_result->isSuccess() && $prod_result->isSuccess()) {
                    return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::success(
                        [
                            'connection_test' => $conn_result->getData(),
                            'product_sync_test' => $prod_result->getData(),
                            'all_tests_passed' => true
                        ],
                        __('Todas las pruebas se ejecutaron correctamente.', 'mi-integracion-api'),
                        [
                            'endpoint' => 'Connection_Tester::run_test',
                            'test_type' => 'all',
                            'connection_success' => $conn_result->isSuccess(),
                            'product_sync_success' => $prod_result->isSuccess(),
                            'timestamp' => time()
                        ]
                    );
                } else {
                    $errors = [];
                    if (!$conn_result->isSuccess()) {
                        $errors[] = $conn_result->getMessage();
                    }
                    if (!$prod_result->isSuccess()) {
                        $errors[] = $prod_result->getMessage();
                    }
                    
                    return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::error(
                        sprintf(__('Errores en las pruebas: %s', 'mi-integracion-api'), implode(' ', $errors)),
                        500,
                        [
                            'endpoint' => 'Connection_Tester::run_test',
                            'error_code' => 'test_failures',
                            'test_type' => 'all',
                            'connection_error' => !$conn_result->isSuccess() ? $conn_result->getMessage() : null,
                            'product_sync_error' => !$prod_result->isSuccess() ? $prod_result->getMessage() : null,
                            'timestamp' => time()
                        ]
                    );
                }
                
            default:
                return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::error(
                    __('Tipo de prueba no válido.', 'mi-integracion-api'),
                    400,
                    [
                        'endpoint' => 'Connection_Tester::run_test',
                        'error_code' => 'invalid_test_type',
                        'test_type' => $test_type,
                        'timestamp' => time()
                    ]
                );
        }
    }
    
    /**
     * Ejecuta la prueba de conexión
     * 
     * @return \MiIntegracionApi\ErrorHandling\Responses\SyncResponseInterface
     */
    public function run_connection_test(): \MiIntegracionApi\ErrorHandling\Responses\SyncResponseInterface {
        try {
            $test_file = $this->plugin_dir . '/connection-test-advanced.php';
            $report_file = $this->plugin_dir . '/generate-report.php';
            
            if (!file_exists($test_file) || !file_exists($report_file)) {
                return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::error(
                    __('No se encontraron los scripts de prueba necesarios.', 'mi-integracion-api'),
                    404,
                    [
                        'endpoint' => 'Connection_Tester::run_connection_test',
                        'error_code' => 'missing_test_scripts',
                        'test_file' => $test_file,
                        'report_file' => $report_file,
                        'timestamp' => time()
                    ]
                );
            }
            
            // Configurar entorno para PHP CLI
            $env = [];
            
            // Preparar el entorno para PHP para que pueda acceder a WordPress si es necesario
            if (defined('ABSPATH')) {
                $env['WP_PATH'] = ABSPATH;
            }
            
            // Ejecutar la prueba de conexión
            $output = $this->execute_php_script($test_file, $env);
            
            if ($output === false) {
                return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::error(
                    __('Error al ejecutar la prueba de conexión.', 'mi-integracion-api'),
                    500,
                    [
                        'endpoint' => 'Connection_Tester::run_connection_test',
                        'error_code' => 'test_execution_failed',
                        'test_file' => $test_file,
                        'timestamp' => time()
                    ]
                );
            }
            
            // Generar el informe HTML
            $report_output = $this->execute_php_script($report_file, $env);
            
            if ($report_output === false) {
                return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::error(
                    __('Error al generar el informe de conexión.', 'mi-integracion-api'),
                    500,
                    [
                        'endpoint' => 'Connection_Tester::run_connection_test',
                        'error_code' => 'report_generation_failed',
                        'report_file' => $report_file,
                        'timestamp' => time()
                    ]
                );
            }
            
            // Guardar una copia en el directorio de resultados
            $results_dir = $this->plugin_dir . '/test-results';
            if (!is_dir($results_dir)) {
                wp_mkdir_p($results_dir);
            }
            
            $date_suffix = date('Y-m-d-H-i-s');
            $result_file = $this->plugin_dir . '/connection-test-results.txt';
            $report_html = $this->plugin_dir . '/connection-test-report.html';
            
            $files_saved = [];
            if (file_exists($result_file)) {
                copy($result_file, $results_dir . '/connection-test-' . $date_suffix . '.txt');
                $files_saved[] = 'connection-test-' . $date_suffix . '.txt';
            }
            
            if (file_exists($report_html)) {
                copy($report_html, $results_dir . '/connection-test-' . $date_suffix . '.html');
                $files_saved[] = 'connection-test-' . $date_suffix . '.html';
            }
            
            return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::success(
                [
                    'test_output' => $output,
                    'report_output' => $report_output,
                    'files_saved' => $files_saved,
                    'results_dir' => $results_dir,
                    'test_completed' => true
                ],
                __('Prueba de conexión ejecutada correctamente.', 'mi-integracion-api'),
                [
                    'endpoint' => 'Connection_Tester::run_connection_test',
                    'test_type' => 'connection',
                    'files_saved_count' => count($files_saved),
                    'timestamp' => time()
                ]
            );
            
        } catch (\Exception $e) {
            return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::error(
                sprintf(__('Error al ejecutar la prueba de conexión: %s', 'mi-integracion-api'), $e->getMessage()),
                500,
                [
                    'endpoint' => 'Connection_Tester::run_connection_test',
                    'error_code' => 'test_exception',
                    'exception_message' => $e->getMessage(),
                    'exception_trace' => $e->getTraceAsString(),
                    'timestamp' => time()
                ]
            );
        }
    }
    
    /**
     * Ejecuta la prueba de sincronización de productos
     * 
     * @return \MiIntegracionApi\ErrorHandling\Responses\SyncResponseInterface
     */
    public function run_product_sync_test(): \MiIntegracionApi\ErrorHandling\Responses\SyncResponseInterface {
        try {
            $test_file = $this->plugin_dir . '/product-sync-test.php';
            
            if (!file_exists($test_file)) {
                return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::error(
                    __('No se encontró el script de prueba de sincronización de productos.', 'mi-integracion-api'),
                    404,
                    [
                        'endpoint' => 'Connection_Tester::run_product_sync_test',
                        'error_code' => 'missing_test_script',
                        'test_file' => $test_file,
                        'timestamp' => time()
                    ]
                );
            }
            
            // Configurar entorno para PHP CLI
            $env = [];
            
            // Preparar el entorno para PHP para que pueda acceder a WordPress
            if (defined('ABSPATH')) {
                $env['WP_PATH'] = ABSPATH;
            }
            
            // Ejecutar la prueba de sincronización de productos
            $output = $this->execute_php_script($test_file, $env);
            
            if ($output === false) {
                return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::error(
                    __('Error al ejecutar la prueba de sincronización de productos.', 'mi-integracion-api'),
                    500,
                    [
                        'endpoint' => 'Connection_Tester::run_product_sync_test',
                        'error_code' => 'test_execution_failed',
                        'test_file' => $test_file,
                        'timestamp' => time()
                    ]
                );
            }
            
            // Guardar una copia en el directorio de resultados
            $results_dir = $this->plugin_dir . '/test-results';
            if (!is_dir($results_dir)) {
                wp_mkdir_p($results_dir);
            }
            
            $date_suffix = date('Y-m-d-H-i-s');
            $result_file = $this->plugin_dir . '/product-sync-test-results.txt';
            $result_json = $this->plugin_dir . '/product-sync-results.json';
            
            $files_saved = [];
            if (file_exists($result_file)) {
                copy($result_file, $results_dir . '/product-sync-' . $date_suffix . '.txt');
                $files_saved[] = 'product-sync-' . $date_suffix . '.txt';
            }
            
            if (file_exists($result_json)) {
                copy($result_json, $results_dir . '/product-sync-' . $date_suffix . '.json');
                $files_saved[] = 'product-sync-' . $date_suffix . '.json';
            }
            
            return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::success(
                [
                    'test_output' => $output,
                    'files_saved' => $files_saved,
                    'results_dir' => $results_dir,
                    'test_completed' => true
                ],
                __('Prueba de sincronización de productos ejecutada correctamente.', 'mi-integracion-api'),
                [
                    'endpoint' => 'Connection_Tester::run_product_sync_test',
                    'test_type' => 'product_sync',
                    'files_saved_count' => count($files_saved),
                    'timestamp' => time()
                ]
            );
            
        } catch (\Exception $e) {
            return \MiIntegracionApi\ErrorHandling\Handlers\ResponseFactory::error(
                sprintf(__('Error al ejecutar la prueba de sincronización de productos: %s', 'mi-integracion-api'), $e->getMessage()),
                500,
                [
                    'endpoint' => 'Connection_Tester::run_product_sync_test',
                    'error_code' => 'test_exception',
                    'exception_message' => $e->getMessage(),
                    'exception_trace' => $e->getTraceAsString(),
                    'timestamp' => time()
                ]
            );
        }
    }
    
    /**
     * Ejecuta un script PHP
     * 
     * @param string $script_path Ruta al script PHP
     * @param array $env Variables de entorno adicionales
     * @return string|bool Salida del script o false si hay un error
     */
    private function execute_php_script($script_path, $env = []) {
        // Verificar si exec está disponible
        if (!function_exists('exec')) {
            // Si exec no está disponible, intentar con include
            ob_start();
            include_once $script_path;
            $output = ob_get_clean();
            return $output;
        }
        
        // Preparar el comando
        $cmd = 'php ' . escapeshellarg($script_path) . ' 2>&1';
        
        // Preparar variables de entorno
        $env_str = '';
        foreach ($env as $key => $value) {
            $env_str .= sprintf('%s=%s ', escapeshellarg($key), escapeshellarg($value));
        }
        
        // Ejecutar el comando
        $output = null;
        $return_var = null;
        exec($env_str . $cmd, $output, $return_var);
        
        if ($return_var !== 0) {
            error_log('Error al ejecutar el script: ' . $script_path . '. Código: ' . $return_var);
            error_log('Salida: ' . implode("\n", $output));
            return false;
        }
        
        return implode("\n", $output);
    }
    
    /**
     * Obtiene el último informe de conexión generado
     * 
     * @return array|bool Datos del informe o false si no hay informes
     */
    public function get_last_connection_report() {
        $report_html = $this->plugin_dir . '/connection-test-report.html';
        $result_file = $this->plugin_dir . '/connection-test-results.txt';
        
        $data = [
            'timestamp' => null,
            'html_path' => null,
            'text_path' => null,
            'has_report' => false,
            'connection_success' => false,
            'wc_success' => false,
            'integration_success' => false
        ];
        
        if (file_exists($report_html)) {
            $data['html_path'] = $report_html;
            $data['timestamp'] = filemtime($report_html);
            $data['has_report'] = true;
        }
        
        if (file_exists($result_file)) {
            $data['text_path'] = $result_file;
            
            // Analizar el contenido para extraer el estado
            $content = file_get_contents($result_file);
            $data['connection_success'] = strpos($content, 'Conexión con Verial: EXITOSA') !== false;
            $data['wc_success'] = strpos($content, 'WooCommerce: DISPONIBLE') !== false;
            $data['integration_success'] = strpos($content, 'Integración: VERIFICADA') !== false;
            
            if (!$data['timestamp']) {
                $data['timestamp'] = filemtime($result_file);
                $data['has_report'] = true;
            }
        }
        
        return $data['has_report'] ? $data : false;
    }
    
    /**
     * Obtiene el último informe de sincronización de productos generado
     * 
     * @return array|bool Datos del informe o false si no hay informes
     */
    public function get_last_product_sync_report() {
        $result_json = $this->plugin_dir . '/product-sync-results.json';
        $result_file = $this->plugin_dir . '/product-sync-test-results.txt';
        
        $data = [
            'timestamp' => null,
            'json_path' => null,
            'text_path' => null,
            'has_report' => false,
            'json_data' => null,
            'products_count' => 0,
            'mapping_success' => false
        ];
        
        if (file_exists($result_json)) {
            $data['json_path'] = $result_json;
            $data['timestamp'] = filemtime($result_json);
            $data['has_report'] = true;
            
            // Cargar datos JSON
            $json_content = file_get_contents($result_json);
            $json_data = json_decode($json_content, true);
            
            if ($json_data) {
                $data['json_data'] = $json_data;
                $data['products_count'] = $json_data['verial_products_count'] ?? 0;
                $data['mapping_success'] = $json_data['mapping_success'] ?? false;
            }
        }
        
        if (file_exists($result_file)) {
            $data['text_path'] = $result_file;
            
            if (!$data['timestamp']) {
                $data['timestamp'] = filemtime($result_file);
                $data['has_report'] = true;
            }
        }
        
        return $data['has_report'] ? $data : false;
    }
}
